import { createFileRoute, Link } from "@tanstack/react-router";
import { getWorld } from "@/worlds/registry";
import { WORLD_SCENES } from "@/worlds/scenes";
import { GameRuntime } from "@/game/GameRuntime";
import { getPortal } from "@/game/portals";
import { useProgress } from "@/game/progress";
import { SPAWN } from "@/game/scene/Player";

export const Route = createFileRoute("/worlds/$worldId")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>): { from?: string | undefined } => ({
    from: typeof search["from"] === "string" ? (search["from"] as string) : undefined,
  }),
  head: ({ params }) => {
    const w = getWorld(params.worldId);
    const title = w ? `${w.title} — Immersive Worlds` : "Unknown World — Immersive Worlds";
    const description = w?.description ?? "A world of the Immersive Worlds platform.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
      ],
    };
  },
  component: WorldRoute,
});

function Message({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <main className="dark flex min-h-screen items-center justify-center bg-background px-6 text-foreground">
      <div className="max-w-md space-y-6 text-center">
        <h1 className="text-2xl font-extralight tracking-[0.3em]">{title}</h1>
        <div className="text-sm text-muted-foreground">{children}</div>
        <Link
          to="/"
          className="inline-block rounded-md border border-border px-5 py-2 text-xs uppercase tracking-widest transition hover:bg-accent"
        >
          Back to world selection
        </Link>
      </div>
    </main>
  );
}

function WorldRoute() {
  const { worldId } = Route.useParams();
  const { from } = Route.useSearch();
  const meta = getWorld(worldId);
  const Scene = WORLD_SCENES[worldId];
  const saved = useProgress((s) => s.worlds[worldId]);

  if (!meta) {
    return <Message title="UNKNOWN WORLD">This world does not exist.</Message>;
  }
  if (!Scene) {
    return (
      <Message title={meta.title}>
        <p>World {meta.order} is still being built. White Silence is the first open district.</p>
      </Message>
    );
  }

  // Portal arrivals spawn at the portal's destination; direct entry resumes at
  // the last saved safe position when one exists.
  const portal = from ? getPortal(from) : undefined;
  const spawn = portal?.to === worldId ? portal.spawn : (saved?.lastPosition ?? SPAWN);
  const spawnYaw = portal?.to === worldId ? portal.spawnYaw : undefined;

  return (
    <GameRuntime worldId={meta.id} title={meta.title} spawn={spawn} spawnYaw={spawnYaw}>
      <Scene />
    </GameRuntime>
  );
}
