import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { RotateCcw, User, Users } from "lucide-react";
import { WORLDS, type WorldMeta } from "@/worlds/registry";
import { useProgress } from "@/game/progress";
import { worldCompletion } from "@/game/portals";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Immersive Worlds — Choose Your World" },
      {
        name: "description",
        content:
          "A browser-based immersive 3D exploration platform. Four virtual worlds, explored on foot in first person.",
      },
      { property: "og:title", content: "Immersive Worlds — Choose Your World" },
      {
        property: "og:description",
        content: "Four virtual worlds, explored on foot in first person.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WorldSelect,
});

function WorldSelect() {
  const discoveries = useProgress((s) => s.discoveries);
  const [confirmReset, setConfirmReset] = useState(false);
  const hasProgress = discoveries.length > 0;
  return (
    <main className="dark min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-6xl px-6 py-16">
        <header className="mb-14 text-center">
          <p className="text-xs uppercase tracking-[0.6em] text-muted-foreground">Immersive Worlds</p>
          <h1 className="mt-4 text-4xl font-extralight tracking-wide md:text-5xl">Choose your world</h1>
          <p className="mt-3 text-sm text-muted-foreground">Four environments. One way in: your own two feet.</p>
        </header>
        <div className="grid gap-8 md:grid-cols-2">
          {WORLDS.map((w) => (
            <WorldCard key={w.id} world={w} />
          ))}
        </div>
        {hasProgress && (
          <footer className="mt-14 flex flex-col items-center gap-3">
            {confirmReset ? (
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span>Erase all discoveries and saved positions?</span>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => {
                    useProgress.getState().resetProgress();
                    setConfirmReset(false);
                  }}
                >
                  Yes, reset everything
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setConfirmReset(false)}>
                  Keep my progress
                </Button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-muted-foreground underline-offset-4 transition hover:text-foreground hover:underline"
              >
                <RotateCcw className="h-3 w-3" /> Reset progression
              </button>
            )}
          </footer>
        )}
      </div>
    </main>
  );
}

function WorldCard({ world }: { world: WorldMeta }) {
  const playable = world.status === "playable";
  const visited = useProgress((s) => s.worlds[world.id]?.visited ?? false);
  const discoveries = useProgress((s) => s.discoveries);
  const progress = worldCompletion(world.id, discoveries);
  return (
    <article className="group overflow-hidden rounded-lg border border-border bg-card">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={world.image}
          alt={`${world.title} — ${world.tagline}`}
          width={1024}
          height={768}
          loading="lazy"
          className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
        />
        {!playable && (
          <span className="absolute right-3 top-3 rounded-full border border-border bg-background/80 px-3 py-1 text-[10px] uppercase tracking-widest text-muted-foreground">
            In development
          </span>
        )}
      </div>
      <div className="space-y-3 p-6">
        <p className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">World {world.order}</p>
        <div className="flex items-baseline gap-3">
          <h2 className="text-2xl font-light tracking-[0.2em]">{world.title}</h2>
          <span className="text-xs italic text-muted-foreground">{world.tagline}</span>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">{world.description}</p>
        {playable && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-muted-foreground">
              <span>{visited ? "Visited" : "Not yet visited"}</span>
              <span>
                {progress.found} / {progress.total} discoveries
              </span>
            </div>
            <div
              className="h-1 overflow-hidden rounded-full bg-secondary"
              role="progressbar"
              aria-valuenow={progress.percent}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`${world.title} exploration`}
            >
              <div className="h-full bg-primary transition-all duration-500" style={{ width: `${progress.percent}%` }} />
            </div>
          </div>
        )}
        <div className="flex gap-3 pt-2">
          {playable ? (
            <Link
              to="/worlds/$worldId"
              params={{ worldId: world.id }}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-xs uppercase tracking-widest text-primary-foreground transition hover:opacity-90"
            >
              <User className="h-3.5 w-3.5" /> Enter solo
            </Link>
          ) : (
            <button
              disabled
              className="inline-flex cursor-not-allowed items-center gap-2 rounded-md bg-secondary px-4 py-2 text-xs uppercase tracking-widest text-muted-foreground"
            >
              <User className="h-3.5 w-3.5" /> Enter solo
            </button>
          )}
          <button
            disabled
            title="Multiplayer needs the network layer — never faked with static avatars. Coming after the vertical slice."
            className="inline-flex cursor-not-allowed items-center gap-2 rounded-md border border-border px-4 py-2 text-xs uppercase tracking-widest text-muted-foreground"
          >
            <Users className="h-3.5 w-3.5" /> Multiplayer — soon
          </button>
        </div>
      </div>
    </article>
  );
}
